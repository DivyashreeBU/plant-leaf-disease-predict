from flask import Flask, render_template, request
import tensorflow as tf
from PIL import Image
import numpy as np
import json
import os

# Initialize Flask app
app = Flask(__name__)

# Load the trained model
model = tf.keras.models.load_model("plant_disease_model.h5")

# Load class names from JSON file
with open("class_names.json") as f:
    class_names = json.load(f)

# Preprocessing function to match model input
def preprocess_image(img):
    img = img.resize((128, 128))
    img = img.convert('RGB')  # Ensure 3 color channels
    img_array = np.array(img) / 255.0
    return np.expand_dims(img_array, axis=0)

# Prediction function with threshold
def predict_from_image(img, threshold=0.6):
    processed_img = preprocess_image(img)
    prediction = model.predict(processed_img)
    predicted_index = np.argmax(prediction)
    confidence = np.max(prediction)

    if confidence < threshold:
        return "Unknown or Uncertain", confidence
    else:
        predicted_class = class_names[predicted_index]
        return predicted_class, confidence

# Route for home page
@app.route('/')
def index():
    return render_template("index.html")

# Route for prediction
@app.route('/predict', methods=["POST"])
def predict():
    if 'image' not in request.files:
        return "No image uploaded", 400
    
    file = request.files['image']
    if file.filename == '':
        return "No selected file", 400

    try:
        img = Image.open(file)
        predicted_class, confidence = predict_from_image(img, threshold=0.6)

        return render_template(
            "result.html",
            prediction=predicted_class,
            confidence=f"{confidence*100:.2f}%"
        )
    
    except Exception as e:
        return f"Error processing image: {str(e)}", 500

# Run the Flask app
if __name__ == "__main__":
    app.run(debug=True)
